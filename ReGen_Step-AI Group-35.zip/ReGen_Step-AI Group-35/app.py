import streamlit as st
import pandas as pd
import plotly.express as px
from sklearn.linear_model import LinearRegression

# Page settings
st.set_page_config(
    page_title="Power Data Analytics Dashboard",
    page_icon="⚡",
    layout="wide"
)

st.title("⚡ Power Data Analytics Dashboard")
st.markdown("Professional interactive dashboard for analyzing Voltage, Current, Weight and Power.")

# Upload dataset
uploaded_file = st.file_uploader("Upload CSV Dataset", type=["csv"])

if uploaded_file:

    df = pd.read_csv(uploaded_file)

    st.success("Dataset Loaded Successfully")

    # -------------------------
    # DATA PREVIEW
    # -------------------------
    st.subheader("Dataset Preview")
    st.dataframe(df)

    # -------------------------
    # SIDEBAR FILTER
    # -------------------------
    st.sidebar.header("Filters")

    if "step_location" in df.columns:
        step = st.sidebar.multiselect(
            "Select Step Location",
            df["step_location"].unique(),
            df["step_location"].unique()
        )

        df = df[df["step_location"].isin(step)]

    # -------------------------
    # STATISTICS
    # -------------------------
    st.subheader("Statistical Summary")
    st.write(df.describe())

    # -------------------------
    # AUTO GRAPH GENERATOR
    # -------------------------
    st.subheader("Auto Graph Generator")

    numeric_columns = df.select_dtypes(include="number").columns

    x_axis = st.selectbox("Select X axis", numeric_columns)
    y_axis = st.selectbox("Select Y axis", numeric_columns)

    chart_type = st.selectbox(
        "Select Chart Type",
        ["Scatter", "Line", "Bar"]
    )

    if chart_type == "Scatter":
        fig = px.scatter(df, x=x_axis, y=y_axis)

    elif chart_type == "Line":
        fig = px.line(df, x=x_axis, y=y_axis)

    else:
        fig = px.bar(df, x=x_axis, y=y_axis)

    st.plotly_chart(fig, use_container_width=True)

    # -------------------------
    # 3D VISUALIZATION
    # -------------------------
    st.subheader("3D Visualization")

    if len(numeric_columns) >= 3:

        x3 = st.selectbox("3D X Axis", numeric_columns, key="x3")
        y3 = st.selectbox("3D Y Axis", numeric_columns, key="y3")
        z3 = st.selectbox("3D Z Axis", numeric_columns, key="z3")

        fig3d = px.scatter_3d(
            df,
            x=x3,
            y=y3,
            z=z3,
            color=z3
        )

        st.plotly_chart(fig3d, use_container_width=True)

    # -------------------------
    # CORRELATION HEATMAP
    # -------------------------
    st.subheader("Correlation Heatmap")

    corr = df.corr(numeric_only=True)

    fig = px.imshow(corr, text_auto=True)

    st.plotly_chart(fig, use_container_width=True)

    # -------------------------
    # MACHINE LEARNING
    # -------------------------
    st.subheader("Power Prediction (Machine Learning)")

    if "Power(mW)" in df.columns:

        features = df.drop(columns=["Power(mW)"])
        features = features.select_dtypes(include="number")

        target = df["Power(mW)"]

        if len(features.columns) > 0:

            model = LinearRegression()
            model.fit(features, target)

            st.write("Enter values to predict Power")

            input_data = {}

            for col in features.columns:
                input_data[col] = st.number_input(col)

            if st.button("Predict Power"):

                input_df = pd.DataFrame([input_data])

                prediction = model.predict(input_df)

                st.success(f"Predicted Power: {prediction[0]:.2f} mW")

    # -------------------------
    # DOWNLOAD DATA
    # -------------------------
    st.subheader("Download Dataset")

    csv = df.to_csv(index=False).encode("utf-8")

    st.download_button(
        label="Download Cleaned Data",
        data=csv,
        file_name="cleaned_dataset.csv",
        mime="text/csv"
    )

else:
    st.info("Upload a CSV dataset to start analysis.")